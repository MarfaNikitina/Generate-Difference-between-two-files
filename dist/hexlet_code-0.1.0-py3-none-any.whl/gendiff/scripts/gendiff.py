# !/usr/bin/env python3
from gendiff.parser_gendiff import make_parser


main = make_parser()


if __name__ == '__main__':
    main()